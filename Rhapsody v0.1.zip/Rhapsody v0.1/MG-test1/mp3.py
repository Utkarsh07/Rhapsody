from midi2audio import FluidSynth
fs = FluidSynth()
FluidSynth('sound_font.sf2')
fs.midi_to_audio('C:\Siddhanth\SI4407\Sem 7\Capstone Project\Rhapsody-Final\Rhapsody v0.1\MG-test1\test3.mid', 'C:\Siddhanth\SI4407\Sem 7\Capstone Project\Rhapsody-Final\Rhapsody v0.1\MG-test1\test3.wav')